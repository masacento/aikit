package encoder

import "math"

// selfAttention runs one block's bidirectional multi-head self-attention
// and adds the output to the residual `h`. Writes the result back into
// `h` so the caller can apply the post-attention LayerNorm in place
// (post-norm structure, plan §6.2).
//
// Shapes throughout this function:
//
//	h:        [L, D]                  hidden states (D = HiddenDim = heads * headDim)
//	Wqkv:     [3D, D]                 fused Q/K/V input projection (PyTorch layout)
//	OutProj:  [D, D]                  attention output projection
//	heads, headDim: D / heads, D / heads
//	rope:     precomputed cos/sin for positions 0..L-1
//
// M8c: takes a *scratch arena so qkv / Q / K / V / ctx / qH/kH/vH /
// scores buffers are reused across the 12 layers per forward (and
// across forwards on the same worker via sync.Pool). Caller must have
// run s.ensureLayer(L, D, intermediate, heads, headDim) at the top of
// the forward.
//
// WqkvB / OutProjB are the optional projection biases: Nomic's original
// checkpoints (CodeRankEmbed, nomic-embed-text-v1.5) carry none, so they pass nil
// and the arithmetic is unchanged; nomic-embed-text-v2-moe sets qkv_proj_bias and
// an out_proj bias, and those rows are broadcast over the sequence.
func selfAttention(h []float32, Wqkv, WqkvB, OutProj, OutProjB []float32, heads, headDim, D, L int, rope *ropeTable, s *scratch) {
	if heads*headDim != D {
		panic("encoder: heads*headDim != D")
	}
	// 1) Project: QKV = h · Wqkvᵀ (+ bias) -> [L, 3D] into scratch.
	qkv := s.qkv[:L*3*D]
	s.mm(h, Wqkv, qkv, L, D, 3*D)
	addRowBias(qkv, WqkvB, L, 3*D)

	// 2) Split QKV into Q, K, V — each [L, D]. Reuse scratch buffers.
	Q := s.Q[:L*D]
	K := s.K[:L*D]
	V := s.V[:L*D]
	for i := range L {
		copy(Q[i*D:(i+1)*D], qkv[i*3*D:i*3*D+D])
		copy(K[i*D:(i+1)*D], qkv[i*3*D+D:i*3*D+2*D])
		copy(V[i*D:(i+1)*D], qkv[i*3*D+2*D:i*3*D+3*D])
	}

	// 3) RoPE on Q and K per head, full headDim, rotate_half.
	rope.apply(Q, heads)
	rope.apply(K, heads)

	// 4) Scaled dot-product attention per head. Scratch holds qH/kH (per-head Q/K
	// extracts), vHT (V transposed to [headDim, L]) and scores ([L, L]). Both
	// matmuls go through the SIMD A·Bᵀ kernel: QKᵀ = qH·kHᵀ, then the context
	// scores·V = scores·(vHT)ᵀ — the latter was a scalar triple-loop and the
	// single hottest line in Encode before this (≈⅓ of total).
	scale := float32(1.0 / math.Sqrt(float64(headDim)))
	ctx := s.ctx[:L*D] // every (i, head) column is written exactly once below
	qH := s.qH[:L*headDim]
	kH := s.kH[:L*headDim]
	vHT := s.vH[:headDim*L]
	ctxHead := s.ctxHead[:L*headDim]
	scores := s.scores[:L*L]

	for headIdx := range heads {
		for i := range L {
			src := i*D + headIdx*headDim
			copy(qH[i*headDim:(i+1)*headDim], Q[src:src+headDim])
			copy(kH[i*headDim:(i+1)*headDim], K[src:src+headDim])
			// V transposed: vHT[d, i] = V[i, head, d], folded into the extract so
			// scores·V can use the A·Bᵀ matmul (which needs Vᵀ as its b operand).
			for d := range headDim {
				vHT[d*L+i] = V[src+d]
			}
		}
		s.mm(qH, kH, scores, L, headDim, L)
		for i := range scores {
			scores[i] *= scale
		}
		softmaxRows(scores, L, L)
		// ctxHead[L, headDim] = scores[L, L] · V[L, headDim], as scores · (vHT)ᵀ.
		s.mm(scores, vHT, ctxHead, L, L, headDim)
		// Scatter this head's context into the interleaved ctx[L, D].
		for i := range L {
			dst := i*D + headIdx*headDim
			copy(ctx[dst:dst+headDim], ctxHead[i*headDim:(i+1)*headDim])
		}
	}

	// 5) Output projection into scratch (+ bias).
	out := s.out[:L*D]
	s.mm(ctx, OutProj, out, L, D, D)
	addRowBias(out, OutProjB, L, D)

	// 6) Residual: h += out (in place).
	for i := range h {
		h[i] += out[i]
	}
}
