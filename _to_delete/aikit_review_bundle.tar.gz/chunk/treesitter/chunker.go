// Package treesitter is ken's v0.2.0 chunker: a pure-Go tree-sitter
// runtime via github.com/odvcencio/gotreesitter, with chunk boundaries
// determined by the cAST split-then-merge algorithm (arXiv 2506.15655 —
// the same algorithm Chonkie uses). Registers itself as "treesitter" in
// the chunk registry on import; blank-imported from internal/search like
// the regex chunker is. External mcp.Run authors can blank-import this
// package to register the chunker before calling mcp.Run (ADR-032).
//
// STABILITY (ADR-032): this is a public package, but a BEST-EFFORT one.
// The exact chunk boundaries it produces are backed by the pre-1.0,
// single-maintainer gotreesitter dep (bus-factor 1, ADR-010) and the
// 1-second per-parse timeout (parseTimeoutMicros), which can yield
// slightly different parses under machine load — chunk counts wobble by
// ~0.1% across rebuilds on large corpora (ken#35). The stable, 1.0-
// committed surface is the chunk.Chunker interface, NOT this chunker's
// byte-for-byte output. Don't pin behavior to a specific boundary; do
// rely on "it produces valid, contiguous, byte-faithful chunks."
//
// Why this exists (ken's DESIGN.md §2 + §10): v0.1.0 measured a 0.012
// hybrid NDCG@10 gap vs semble (0.842 vs 0.854) localized to languages
// where ken's regex chunker draws different boundaries than semble's
// tree-sitter chunker. Python with hand-tuned regex tracked semble
// exactly (+0.003); go/rust/zig sat at −0.05. This package closes that
// gap by replacing per-language regex with AST traversal. The regex
// chunker stays registered ("--chunker=regex") for users who don't want
// the +20 MB grammar bloat or the gotreesitter dep.
//
// Load-bearing invariants the rest of the codebase depends on:
//
//   - **cAST split-then-merge** (cast.go). Pass 1 walks the AST top-
//     down: for each named node whose byte span exceeds chunkSize,
//     recurse into its named children instead of emitting it as a
//     whole. Pass 2 walks the resulting span list in order, greedily
//     merging adjacent spans while their combined span ≤ chunkSize.
//     Inter-span gaps (whitespace, comments, blank lines) are absorbed
//     into whichever chunk straddles them, preserving the byte-fidelity
//     invariant from internal/chunk (concat == source). Changing either
//     pass's loop structure breaks byte-fidelity; tests cross-check it
//     per language.
//   - **gotreesitter dep is pinned at the major.minor in go.mod.** It
//     is pre-1.0 with a single maintainer (bus-factor: 1, ADR-010 risk).
//     The chunker.Chunker interface (ADR-005) is the swap-out path if
//     the dep ever needs to be replaced. Don't lift internal types
//     across the interface boundary — keep all gotreesitter-specific
//     state inside this package.
//   - **Per-language ParserPool cache.** Indexing a real repo calls
//     Chunk() once per file (thousands of files of the same language).
//     Allocating a fresh gotreesitter.Parser on every call burned tens
//     of minutes per bench repo (measured during v0.2.0 development).
//     ParserPool is a sync.Pool-backed reusable parser designed for
//     this; we cache one *ParserPool per gotreesitter language, lazily
//     created on first use, in a sync.Map so the Chunker stays safe to
//     share across goroutines.
//   - **Per-parse timeout (parseTimeoutMicros, 1s).** Some grammars
//     have pathological inputs (the gotreesitter v0.18.0 bash grammar
//     hangs indefinitely on real bash-it content). The timeout aborts
//     a runaway parse and falls through to fallback(), which routes
//     the file to the registered "line" chunker instead of emitting a
//     single whole-file chunk (whole-file fallback regressed bash NDCG
//     by 0.119 in measurement; the current behavior matches what the
//     regex chunker does for unsupported languages).
//   - **Deliberate language omissions** (languages.go). The C# grammar
//     OOMs on real-world C# (1.7+ GB RSS → SIGKILL); bash grammar is
//     too slow even with the timeout. Both are absent from
//     KenToTreeSitter and auto-fall-back to the line chunker, matching
//     the regex chunker's behavior for those languages. Revisit when
//     gotreesitter ships bounded-memory C# or a faster bash grammar.
package treesitter

import (
	"sort"
	"sync"
	"sync/atomic"

	"github.com/odvcencio/gotreesitter"
	"github.com/odvcencio/gotreesitter/grammars"

	"github.com/townsendmerino/aikit/chunk"
)

// Chunker implements chunk.Chunker over gotreesitter grammars + cAST.
// Stateless conceptually (no mutable user-visible state) but caches
// ParserPool/Language values internally so repeated calls don't repay
// the parser-allocation or grammar-lookup cost per file.
type Chunker struct {
	// pools maps a kenLanguageName (e.g. "go", "rust") to a *ParserPool
	// initialized lazily on first use. sync.Map is the right shape
	// because the read-heavy access pattern (one read per file, one
	// write per first-seen language) is what sync.Map is optimized for.
	pools sync.Map // map[string]*gotreesitter.ParserPool

	// lineFallback is the universally-registered "line" chunker, used
	// when a treesitter parse times out or fails. Cached on first use
	// (the chunk package's init() registers "line" before any
	// sub-package code runs, so the lookup is safe at any call time).
	lineOnce     sync.Once
	lineCh       chunk.Chunker
	lineLookupOK bool

	// Per-reason fallback counters. Atomic-incremented at each of the
	// four silent-fallback sites in Chunk so callers (`ken perf index`,
	// the OSS-demo build-time validation) can quantify how many files
	// actually got AST chunks vs degraded to the line chunker. Exposed
	// via Stats(); zero allocations on the hot path. ADR-010
	// graceful-degradation behavior is unchanged.
	total           atomic.Int64
	unsupportedLang atomic.Int64
	parseErr        atomic.Int64
	nilRoot         atomic.Int64
	invalidSpans    atomic.Int64
}

// Stats is a point-in-time snapshot of the treesitter chunker's
// per-reason fallback counters since process start (or since the
// Chunker was constructed). Read via Chunker.Stats(). Concurrency-safe:
// each field is loaded with an atomic.Load, so the snapshot is
// internally consistent for each counter but the four counters are not
// captured atomically as a group — a few sub-microsecond skew across
// fields is possible when reading mid-indexing. For the OSS-demo
// validation use case (read once after FromFS returns), the snapshot
// is point-stable.
//
// Fallback is the sum of the four per-reason counters and is what the
// demo decision wants: "of the files we tried to AST-chunk, how many
// silently degraded to line-chunking?"
type Stats struct {
	Total           int64 `json:"total"`
	Fallback        int64 `json:"fallback"`
	UnsupportedLang int64 `json:"unsupported_lang"`
	ParseErr        int64 `json:"parse_err"`
	NilRoot         int64 `json:"nil_root"`
	InvalidSpans    int64 `json:"invalid_spans"`
}

// Stats returns a point-in-time snapshot of the chunker's per-reason
// fallback counters. Safe to call from any goroutine while indexing is
// in progress; safe to call multiple times (counters keep accumulating
// across calls, so two snapshots N and N+1 let you compute a delta).
func (c *Chunker) Stats() Stats {
	unsupportedLang := c.unsupportedLang.Load()
	parseErr := c.parseErr.Load()
	nilRoot := c.nilRoot.Load()
	invalidSpans := c.invalidSpans.Load()
	return Stats{
		Total:           c.total.Load(),
		Fallback:        unsupportedLang + parseErr + nilRoot + invalidSpans,
		UnsupportedLang: unsupportedLang,
		ParseErr:        parseErr,
		NilRoot:         nilRoot,
		InvalidSpans:    invalidSpans,
	}
}

// New returns a tree-sitter chunker. The internal caches are empty;
// they fill lazily as files in each language are encountered.
func New() *Chunker { return &Chunker{} }

func init() { chunk.Register("treesitter", New()) }

func (*Chunker) Name() string { return "treesitter" }

// SupportedLanguages returns ken's canonical language names for which
// a gotreesitter grammar exists. ChunkFile uses this set to decide
// whether to route a file here or fall back to the line chunker — so
// this is exhaustive of what the treesitter chunker can handle, not a
// curated subset.
func (*Chunker) SupportedLanguages() []string {
	out := make([]string, 0, len(KenToTreeSitter))
	for k := range KenToTreeSitter {
		out = append(out, k)
	}
	return out
}

// poolFor returns a cached ParserPool for the given ken language, or
// creates one (and caches it) on first use. Returns nil if the
// language isn't supported by the treesitter chunker or its grammar
// isn't registered in gotreesitter.
//
// The lazy-init handles two cost components per language:
//  1. grammars.DetectLanguageByName + entry.Language() — decompresses
//     the embedded grammar blob on first call (one-time, then cached
//     inside gotreesitter itself).
//  2. gotreesitter.NewParserPool — allocates the sync.Pool. Cheap.
//
// All subsequent Chunk() calls for the same language hit the cache
// and just check out a parser from the pool (atomic op, no allocation
// on the hot path).
func (c *Chunker) poolFor(kenLang string) *gotreesitter.ParserPool {
	if v, ok := c.pools.Load(kenLang); ok {
		return v.(*gotreesitter.ParserPool)
	}
	tsName, ok := KenToTreeSitter[kenLang]
	if !ok {
		return nil
	}
	entry := grammars.DetectLanguageByName(tsName)
	if entry == nil {
		return nil
	}
	lang := entry.Language()
	if lang == nil {
		return nil
	}
	// Per-parse timeout: bound the worst-case parse to bail out of a
	// pathological input rather than hang the indexer. Some grammars
	// have rare quadratic-or-worse inputs (bash-it's lib/helpers.bash
	// at v0.2.0 indexing was the discovery case — 36+ minutes on one
	// file in the bash grammar). gotreesitter's published per-parse
	// time is ~2ms; parseTimeoutSeconds gives ~5000× slack for genuinely
	// large real files, and any parse exceeding it returns a truncated tree that
	// Chunk detects via tree.ParseStoppedEarly() and routes to the line-chunker
	// fallback (gotreesitter >=0.40 no longer surfaces the timeout as an error).
	pool := gotreesitter.NewParserPool(lang,
		gotreesitter.WithParserPoolTimeoutMicros(parseTimeoutMicros),
	)
	// LoadOrStore handles the race where two goroutines both miss
	// the cache for the same first-seen language: the second one
	// returns the first one's pool (its own is discarded).
	actual, _ := c.pools.LoadOrStore(kenLang, pool)
	return actual.(*gotreesitter.ParserPool)
}

// parseTimeoutMicros bounds the worst-case tree-sitter parse so a
// pathological file can't hang the indexer for the whole repo. See
// poolFor for the rationale.
//
// Empirically calibrated: gotreesitter's published per-parse time is
// ~2 ms. Bash on real bash-it content (esp. lib/helpers.bash and the
// completion/* tree) hit a quadratic-or-worse parse path that the
// initial 10-second budget failed to recover from in any reasonable
// total time (17 min for bash-it alone, 989 chunks). 1 second is still
// 500× the published parse time, generous enough for legitimately large
// real files, and tight enough to cap a runaway parse at <1% of total
// indexing time per pathological file.
const parseTimeoutMicros uint64 = 1_000_000

// Chunk parses source with the appropriate grammar (via the cached
// per-language ParserPool), runs cAST, and converts the resulting
// byte spans into chunk.Chunks. Concatenating the returned Text
// fields in order reproduces source exactly (the byte-fidelity
// invariant from internal/chunk/regex).
//
// If the language is not in KenToTreeSitter, the grammar isn't
// registered, or the parser times out / fails, the chunker degrades
// to the registered "line" chunker — NOT to a single whole-file
// chunk. Whole-file fallback is catastrophic for BM25 (the entire
// file becomes one token bag and IDF/TF break), measured empirically
// during v0.2.0 development on bash-it. The line chunker preserves
// roughly the same retrieval quality as the regex chunker's fallback.
func (c *Chunker) Chunk(source []byte, language string, chunkSize int) ([]chunk.Chunk, error) {
	if len(source) == 0 {
		return nil, nil
	}
	if chunkSize <= 0 {
		chunkSize = chunk.DefaultChunkSize
	}
	// Count this call as one "file attempted" for the Stats snapshot.
	// The atomic add is negligible relative to parse cost; placing it
	// after the len==0 guard so empty sources (which return nil chunks
	// without doing any parsing) aren't included in the denominator.
	c.total.Add(1)

	pool := c.poolFor(language)
	if pool == nil {
		// Language unsupported or grammar unavailable. Degrade to
		// the line chunker rather than emit a single whole-file chunk.
		c.unsupportedLang.Add(1)
		return c.fallback(source, language, chunkSize)
	}

	tree, err := pool.Parse(source)
	if err != nil {
		// A hard parse error. Fall back to the line chunker so the file still
		// produces useful BM25 docs.
		c.parseErr.Add(1)
		return c.fallback(source, language, chunkSize)
	}
	// gotreesitter ≥ 0.40 preserves tree-sitter's native partial-tree behavior on
	// timeout: it returns a TRUNCATED tree with a nil error (0.20 returned an
	// error here). Chunking that partial tree would give degraded boundaries for
	// the unparsed tail, and the runaway-parse guard — the whole reason the
	// per-parse timeout exists — would silently never trip. Detect the early stop
	// (timeout/cancellation) and fall back, restoring the pre-bump contract.
	if tree.ParseStoppedEarly() {
		c.parseErr.Add(1)
		return c.fallback(source, language, chunkSize)
	}
	root := tree.RootNode()
	if root == nil {
		c.nilRoot.Add(1)
		return c.fallback(source, language, chunkSize)
	}

	spans := cAST(root, uint32(len(source)), uint32(chunkSize))
	// Belt-and-braces: layer 1 (splitNode's end<start guard in cast.go)
	// catches degenerate single nodes from gotreesitter ERROR-recovery;
	// this layer catches sibling-ordering defects the cAST re-derive
	// pass can still produce when gotreesitter emits siblings whose
	// start bytes aren't monotonic. If anything still looks wrong, fall
	// back to the line chunker rather than panic in the slice op below.
	if !spansValid(spans, uint32(len(source))) {
		c.invalidSpans.Add(1)
		return c.fallback(source, language, chunkSize)
	}
	// Index the source's newline offsets ONCE so each span's line number is an
	// O(log lines) binary search instead of a from-byte-0 rescan. The old
	// per-span bytesBefore was O(Σ sp.end) ≈ O(N²/chunkSize) — tens of seconds
	// on a multi-MB file, dwarfing the 1s parse timeout the package added to
	// bound per-file cost (M5). linesBefore(end) == count of '\n' in
	// source[:end], byte-identical to bytesBefore; robust to any span order
	// (spansValid does not guarantee monotonic spans).
	nlOffsets := newlineOffsets(source)
	linesBefore := func(end uint32) int {
		if end > uint32(len(source)) {
			end = uint32(len(source))
		}
		return sort.Search(len(nlOffsets), func(i int) bool { return nlOffsets[i] >= end })
	}
	out := make([]chunk.Chunk, len(spans))
	for i, sp := range spans {
		text := string(source[sp.start:sp.end])
		out[i] = chunk.Chunk{
			StartLine: 1 + linesBefore(sp.start),
			EndLine:   1 + linesBefore(sp.end) - trailingNewlineCorrection(text),
			Text:      text,
		}
	}
	return out, nil
}

// newlineOffsets returns the byte offsets of every '\n' in source (ascending),
// so linesBefore can binary-search them. O(N) once per Chunk call.
func newlineOffsets(source []byte) []uint32 {
	var offs []uint32
	for i := range source {
		if source[i] == '\n' {
			offs = append(offs, uint32(i))
		}
	}
	return offs
}

// fallback delegates to the registered "line" chunker. This is the
// graceful-degrade path when (a) the language isn't in KenToTreeSitter
// (e.g. csharp, deliberately omitted), (b) the grammar isn't
// registered, (c) the parse timed out, or (d) the parse returned a nil
// tree. Whole-file fallback was the original v0.2.0 behavior; it
// regressed bash NDCG by 0.118 because BM25 collapses a giant single
// document into noise, and was replaced with line chunking after the
// first bench run.
//
// If chunk.Get("line") somehow fails (only possible if the registry
// hasn't initialized — shouldn't happen since chunk's init() registers
// "line" before any sub-package code runs), we degrade further to a
// single whole-file chunk so the call still returns valid output.
func (c *Chunker) fallback(source []byte, language string, chunkSize int) ([]chunk.Chunk, error) {
	c.lineOnce.Do(func() {
		if ch, err := chunk.Get("line"); err == nil {
			c.lineCh = ch
			c.lineLookupOK = true
		}
	})
	if !c.lineLookupOK {
		return wholeFileChunk(source), nil
	}
	return c.lineCh.Chunk(source, language, chunkSize)
}

// wholeFileChunk is the last-resort fallback when even chunk.Get("line")
// fails. Preserved as a safety net but no longer the primary fallback
// path — see fallback() above.
func wholeFileChunk(source []byte) []chunk.Chunk {
	text := string(source)
	end := 1 + bytesBefore('\n', source, uint32(len(source))) - trailingNewlineCorrection(text)
	return []chunk.Chunk{{StartLine: 1, EndLine: end, Text: text}}
}

// bytesBefore counts occurrences of c in source[:end]. We use it to
// convert a byte offset into a 1-indexed line number without depending
// on an external "byte→line" library.
func bytesBefore(c byte, source []byte, end uint32) int {
	if end > uint32(len(source)) {
		end = uint32(len(source))
	}
	n := 0
	for i := uint32(0); i < end; i++ {
		if source[i] == c {
			n++
		}
	}
	return n
}

// trailingNewlineCorrection accounts for chunks that end with '\n':
// a chunk like "foo\nbar\n" spans two lines (1, 2), but counting all
// '\n' in source up to the chunk's end-byte would yield 2 newlines and
// suggest EndLine=3. Subtract 1 when the chunk's last byte is '\n' so
// the displayed range matches what semble and the regex chunker emit.
func trailingNewlineCorrection(text string) int {
	if len(text) > 0 && text[len(text)-1] == '\n' {
		return 1
	}
	return 0
}
